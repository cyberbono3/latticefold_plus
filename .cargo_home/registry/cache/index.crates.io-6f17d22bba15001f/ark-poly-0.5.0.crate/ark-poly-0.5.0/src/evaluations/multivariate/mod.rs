pub mod multilinear;
pub use multilinear::{
    DenseMultilinearExtension, MultilinearExtension, SparseMultilinearExtension,
};
