//! # Example: REPL (Derive API)
//!
//! ```rust
#![doc = include_str!("../../examples/repl-derive.rs")]
